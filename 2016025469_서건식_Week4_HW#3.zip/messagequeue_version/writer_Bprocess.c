#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

typedef struct msgbuf
{
        long msgtype;
        char mtext[20];
} msgbuf;

int main(void)
{
	key_t key_id;
	int i=0;
	msgbuf sndbuf;

	key_id = msgget((key_t)1234, IPC_CREAT|0666);

	if(key_id == -1)
	{
		perror("msgget error : ");
		return 0;
	}

	sndbuf.msgtype = 3;
	while(1){

		scanf("%s",&sndbuf.mtext);

		if(msgsnd(key_id,(void *)&sndbuf, sizeof(msgbuf),IPC_NOWAIT) == -1)
		{
		perror("msgend error : ");
		}
		printf("Sending %dth message is succeed\n",i);
		i++;
		if(i == 10){
			printf("You sent 10 messages. END\n");
			break;
		}

	}

	printf("send");
	return 0;
}
