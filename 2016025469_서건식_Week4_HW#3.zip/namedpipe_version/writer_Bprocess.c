#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#define MSG_SIZE 80
#define PIPENAME "./named_pipe_file"

int main()
{
	char msg[MSG_SIZE];
	int fd;
	int ret;
	int i=0;

	//open the named pipe
	fd = open(PIPENAME,O_WRONLY);
	if(fd<0)
	{
		printf("Open failed\n");
		return 0;
	}

	printf("Hello, this is B process. I'll give the data to A (limit: 10 data)\n");
	while(1)
	{
		
		scanf("%s",&msg);
		ret = write(fd,msg,sizeof(msg));
		if(ret <0)
		{
			printf("Write failed\n");
			return 0;
		}
		i++;
		if(i == 10){
			printf("END\n");
			break;
		}
	}




}


