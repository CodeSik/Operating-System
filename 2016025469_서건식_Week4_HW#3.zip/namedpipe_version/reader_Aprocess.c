#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define PIPENAME "./named_pipe_file"

int main()
{
	int ret;
	char msg[512];
	int fd;
	pid_t pid;
	int i =0;
	ret = access(PIPENAME, F_OK);
	if(ret == 0)
	{
		unlink(PIPENAME);
	}

	//create a named pipe
	ret = mkfifo(PIPENAME,0666);
	
	if(ret<0)
	{
		printf("Creation of named pipe failed\n");
	}

	//open the named pipe
	fd = open(PIPENAME, O_RDWR);
	if(fd <0)
	{
		printf("Opening of named pipe failed\n");
		return 0;
	}

		printf("Hello, this is A process. give me the data.\n");
	while(1)
	{
		ret = read(fd,msg,sizeof(msg));
		if(ret <0)
		{
			printf("Read failed\n");
			return 0;
		}
		printf("%s\n",msg);
		i++;
		if(i==10-1){
			printf("END\n");
			break;
		}
	}
	return 0;


}





