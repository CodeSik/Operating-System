#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define READ_FLAG 0
#define WRITE_FLAG 1
#define PRINT_FLAG 2
int main(void)
{
	int shmid;
	char *shmaddr;
	char *string;
	int ret;
	int i=0;

	//get shared memory id
	shmid = shmget((key_t)1234, 1024, IPC_CREAT|0666);
	if(shmid == -1)
	{
		perror("shared memory access is failed\n");
		return 0;
	}

	//attach the shared memory to process memory space
	shmaddr = shmat(shmid,NULL ,0);
	if(shmaddr == (char*)-1)
	{
		perror("attach failed\n");
		return 0;
	}	
	string = shmaddr+1;
	shmaddr[0]= READ_FLAG;
	while(1){
		if(shmaddr[0] == WRITE_FLAG)
		{
			printf("data read from shared memory: %s\n",string);
			i++;
			shmaddr[0] = READ_FLAG;
			if(i==10)
			{
				printf("Receive 10 messages. END\n");
				break;
			}
		}

	}
	ret = shmdt(shmaddr);
	if(ret == -1)
	{
		perror("detach failed\n");
		return 0;
	}

	ret = shmctl(shmid, IPC_RMID,0);
	if(ret == -1)
	{
		perror("remove failed\n");
		return 0;
	}
	return 0;
}
