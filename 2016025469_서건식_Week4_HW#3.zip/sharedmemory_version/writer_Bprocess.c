#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>

#define MSG_SIZE 80
#define READ_FLAG 0
#define WRITE_FLAG 1
#define PRINT_FLAG 2

int main(void)
{
	int shmid;
	int i =0;
	char *shmaddr;
	char* string;
	char* msg[MSG_SIZE];
	int ret;
	shmid = shmget((key_t)1234,1024,IPC_CREAT|0666);

	if(shmid<0)
	{
		perror("shmget error");
		return 0;
	}

	//attach
	
	shmaddr = shmat(shmid,NULL,0);
	if(shmaddr == (char*)-1)
	{
		perror("attach failed\n");
		return 0;
	}
	string = shmaddr +1;
	shmaddr[0] = READ_FLAG;
	while(1)
	{
		scanf("%s",msg);
		if(shmaddr[0] ==READ_FLAG)
		{
			strcpy(string,msg);
			shmaddr[0] = WRITE_FLAG;
			i++;
			if(i == 10)
			{
				printf("Send 10 messages. END\n");
				break;
			}

		}
	}
        ret = shmdt(shmaddr);
	if(ret == -1)
	{
		perror("detach failed\n");
		return 0;
	}
	return 0;



}
