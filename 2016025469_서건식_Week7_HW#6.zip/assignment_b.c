#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#define P 6

void *philos(void *k);

sem_t chopsticks[P];
pthread_t philosopher[P];

void *philos(void *num)
{
   int k;
   k = (int)num;
   int cnt = 0;
   while(cnt <= 15)
   {
      if(k%2==0)
      {
         sem_wait(&chopsticks[k]);
         printf("philosopher[%d], pick up the chopsticks[%d]\n", k,k);
         sleep(1);
         sem_wait(&chopsticks[(k+1)%P]);   
         printf("philosopher[%d], pick up the chopsticks[%d]\n", k,k+1);
         sleep(1);
      }
      else if(k%2==1)
      {
         sem_wait(&chopsticks[(k+1)%P]);
         printf("philosopher[%d], pick up the chopsticks[%d]\n", k,k+1);
         sleep(1);
         sem_wait(&chopsticks[k]);
         printf("philosopher[%d], pick up the chopsticks[%d]\n", k,k);
         sleep(1);
      }
      printf("philosopher[%d] eating\n",k); 
      cnt++;
      sem_post(&chopsticks[k]);
      sem_post(&chopsticks[(k+1)%P]);
   }
}


int main(void)
{
   int i;
   for(i=0; i<P; i++)
   {
      sem_init(&chopsticks[i],0,1);
   }
   for(i=0; i<P; i++)
   {
      pthread_create(&philosopher[i], NULL, (void *)philos, (void *)i);
   }
   for(i=0; i<P; i++)
   {
      pthread_join(philosopher[i],NULL);
   }
   
   for(i=0; i<P; i++)
   {
      sem_destroy(&chopsticks[i]);
   }

   return 0;

}
