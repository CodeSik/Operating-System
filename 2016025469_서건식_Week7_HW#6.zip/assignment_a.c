#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#define COUNTING_NUMBER 100
void reader();
void writer();

sem_t s_reader;
sem_t s_writer;

int cur_writer = 0;
int cur_count = 0;
int readcount=0;

void reader()
{
   for(int i=0; i<COUNTING_NUMBER; i++)
   {
      usleep( 30000 );
      //lock
      sem_wait(&s_reader);
      readcount++;
      if(readcount == 1) sem_wait(&s_writer);
      sem_post(&s_reader);

      printf("The most recent writer id: [%d], count: [%d]\n", cur_writer, cur_count);

      sem_wait(&s_reader);
      readcount --;
      if(readcount == 0) sem_post(&s_writer);

      sem_post(&s_reader);

   }
}
void writer(void* k)
{
   int n;
   n = (int)k;
   for(int i=0; i<COUNTING_NUMBER; i++)
   {
      usleep( 100000);
      sem_wait(&s_reader);
      sem_wait(&s_writer);
      cur_writer = n;
      cur_count++ ;
      sem_post(&s_reader);
      sem_post(&s_writer);
   }
}

int main(void)
{
   int i;

   sem_init(&s_reader, 0, 1);
   sem_init(&s_writer, 0, 1);

   pthread_t thread_reader, thread_writer;
   for(i=0; i<2; i++)
   {
      pthread_create(&thread_reader, NULL,(void*)&reader, NULL);

   }
   for(i=0; i<5; i++)
   {
      pthread_create(&thread_writer, NULL, (void*)&writer, (void *)i);

   }


   
   pthread_join(thread_writer, NULL);
   pthread_join(thread_reader, NULL);

   sem_destroy(&s_reader);
   sem_destroy(&s_writer);

   return 0;
}

