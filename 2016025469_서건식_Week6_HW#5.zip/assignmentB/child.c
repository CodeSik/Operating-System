#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>


#define COUNTING_NUMBER 2000000



typedef struct smStruct{
        int processidassign;
        int turn;
        int flag[2];
        int critical_section_variable;
} smStruct;

//lock. Myorder is processid.
void lock(smStruct *smstruct ,int Myorder)
{
        smstruct->flag[Myorder] = 1;
        smstruct->turn = 1-Myorder;
        while(smstruct->flag[1-Myorder] == 1 && smstruct->turn == 1-Myorder);
}
//unlock. Myorder is processid.
void unlock(smStruct *smstruct,int Myorder)
{
        smstruct->flag[Myorder] = 0;
}

int main(void)
{
	pid_t pid;
        int shmid;
        char * shmaddr;
        int ret;
	int i = 0;
	int localcount = 0;
	smStruct *smstruct;
	int Myorder;

        //get shared memory id
        shmid = shmget((key_t)1234, 1024, IPC_CREAT|0666);
        if(shmid == -1)
        {
                perror("shared memory access is failed\n");
                return 0;
        }

        //attach the shared memory to process memory space
        shmaddr = shmat(shmid,(void*)0 ,0);
        if(shmaddr == (char*)-1)
        {
                perror("attach failed\n");
                return 0;
        }
	smstruct = shmaddr;
	//if processidassign is 0, set Myorder variable to that, and +1
	if(smstruct->processidassign == 0)
	{
		Myorder = smstruct->processidassign;
		smstruct->processidassign++;
	}
	//So the other child process can set Myorder variable to 1.
	else
	{
		Myorder = smstruct->processidassign;
	}

	pid = getpid();
	printf("Myorder = %d,process pid = %d\n",Myorder,pid);
	for(i = 0 ; i<COUNTING_NUMBER ; i++)
	{
		localcount++;
		lock(smstruct, Myorder);
		smstruct -> critical_section_variable++;
		unlock(smstruct,Myorder);
	}
	printf("child finish! local count = %d\n",localcount);

	//Only detach. Delete process will be run in Parent process.
	ret = shmdt(shmaddr);
      	if(ret == -1)
      	{
    	       	perror("detach failed\n");
        	return 0;
   	}




        return 0;
}
